# UI - Flip Card (using :focus-within for a11y)

A Pen created on CodePen.io. Original URL: [https://codepen.io/AbubakerSaeed/pen/EJrRvY](https://codepen.io/AbubakerSaeed/pen/EJrRvY).

