// By @AbubakerSaeed96 (twitter)
// ===================

// Images are from Unsplash.

// Looks Good In Firefox
// Font not displaying correctly in Chrome and Opera
// Looks Good In Edge Dev (Almost)

// Thank You For Viewing.